euromomo
========

Developement branch for the EuroMoMo hackathon
